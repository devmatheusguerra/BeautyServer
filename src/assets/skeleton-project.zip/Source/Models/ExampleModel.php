<?php

namespace Source\Models;


class ExampleModel
{
    public function __construct()
    {
    }
}
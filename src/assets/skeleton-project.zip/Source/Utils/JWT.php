<?php


namespace Source\Utils;


/**
 * [JWT Class]
 */
class JWT
{

    /**
     * @param String $data
     * 
     * @return String
     */
    private static function format(String $data): String
    {
        $data = base64_encode($data);
        $length = strlen($data);
        return str_replace("/", "_", str_replace("+", "-", $data, $length), $length);
    }

    /**
     * @param String $data
     * 
     * @return String
     */
    private static function unformat(String $data): String
    {
        $length = strlen($data);
        $data = str_replace("_", "/", str_replace("-", "+", $data, $length), $length);
        return base64_decode($data);
    }


    /**
     * @param String $header
     * @param String $payloader
     * 
     * @return String
     */
    public static function generate(String $header,  String $payloader): String
    {
        $header = self::format($header);
        $payloader = self::format($payloader);
        $sign = hash_hmac('sha512', $header . "." . $payloader, JWT_KEY, true);
        $sign = base64_encode($sign);
        $sl = strlen($sign);
        str_replace("/", "_", str_replace("+", "-", $sign, $sl), $sl);
        $token = $header . '.' . $payloader . '.' . $sign;
        return $token;
    }

    /**
     * @return bool
     */
    public static function validate(): bool
    {
        $headers = getallheaders();
        $Auth = explode(" ", $headers['Authorization'])[1];
        $tokens = explode(".", $Auth);
        $header = $tokens[0];
        $payload = $tokens[1];
        $signature = $tokens[2];
        $verifier = explode(".", self::generate(self::unformat($header), self::unformat($payload)))[2];
        if ($verifier === $signature) {
            return true;
        } else {
            return false;
        }
    }
}
<?php


namespace Source\Controller;


class ExampleController
{
    public function __construct()
    {
    }
}
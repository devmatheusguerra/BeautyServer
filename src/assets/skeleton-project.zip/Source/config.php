<?php
define('JWT_KEY', 'YOUR JWT KEY HERE');